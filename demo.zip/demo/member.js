// 模拟会员数据
const memberData = {
    name: '张三',
    phone: '13888888888',
    email: 'zhangsan@example.com',
    registerTime: '2024-01-01',
    balanceHistory: [
        { date: '2024-01-01', balance: 0 },
        { date: '2024-01-10', balance: 1000 },
        { date: '2024-01-15', balance: 1500 },
        { date: '2024-01-16', balance: 1300 },
        { date: '2024-01-20', balance: 2300 }
    ]
};

// 页面加载完成后执行
document.addEventListener('DOMContentLoaded', () => {
    // 更新个人信息
    updateProfileInfo();
    
    // 初始化余额趋势图表
    initBalanceChart();

    // 添加编辑按钮事件监听
    addEditButtonListeners();

    // 退出登录按钮事件
    document.getElementById('logoutBtn').addEventListener('click', handleLogout);
});

// 更新个人信息
function updateProfileInfo() {
    document.getElementById('name').textContent = memberData.name;
    document.getElementById('phone').textContent = memberData.phone;
    document.getElementById('email').textContent = memberData.email;
    document.getElementById('registerTime').textContent = memberData.registerTime;
}

// 初始化余额趋势图表
function initBalanceChart() {
    const ctx = document.getElementById('balanceChart').getContext('2d');
    
    new Chart(ctx, {
        type: 'line',
        data: {
            labels: memberData.balanceHistory.map(item => item.date),
            datasets: [{
                label: '账户余额',
                data: memberData.balanceHistory.map(item => item.balance),
                borderColor: '#1e88e5',
                backgroundColor: 'rgba(30, 136, 229, 0.1)',
                fill: true,
                tension: 0.4
            }]
        },
        options: {
            responsive: true,
            maintainAspectRatio: false,
            plugins: {
                legend: {
                    display: false
                }
            },
            scales: {
                y: {
                    beginAtZero: true,
                    ticks: {
                        callback: function(value) {
                            return '￥' + value;
                        }
                    }
                }
            }
        }
    });
}

// 添加编辑按钮事件监听
function addEditButtonListeners() {
    const editButtons = document.querySelectorAll('.edit-btn');
    
    editButtons.forEach(button => {
        button.addEventListener('click', function() {
            const infoItem = this.parentElement;
            const label = infoItem.querySelector('label').textContent;
            const span = infoItem.querySelector('span');
            const currentValue = span.textContent;

            // 创建输入框
            const input = document.createElement('input');
            input.type = 'text';
            input.value = currentValue;
            input.style.width = '200px';
            input.style.padding = '4px';
            input.style.marginRight = '8px';

            // 创建保存按钮
            const saveBtn = document.createElement('button');
            saveBtn.textContent = '保存';
            saveBtn.className = 'edit-btn';

            // 替换内容
            span.style.display = 'none';
            this.style.display = 'none';
            infoItem.insertBefore(input, this);
            infoItem.insertBefore(saveBtn, this);

            // 保存按钮点击事件
            saveBtn.addEventListener('click', function() {
                const newValue = input.value.trim();
                if (newValue) {
                    span.textContent = newValue;
                    // 这里可以添加保存到服务器的逻辑
                }
                
                // 恢复原始显示
                span.style.display = '';
                button.style.display = '';
                input.remove();
                saveBtn.remove();
            });
        });
    });
}

// 处理退出登录
function handleLogout(e) {
    e.preventDefault();
    if (confirm('确定要退出登录吗？')) {
        // 这里可以添加退出登录的逻辑
        window.location.href = 'login.html';
    }
} 