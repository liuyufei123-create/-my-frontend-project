// 页面加载完成后执行
document.addEventListener('DOMContentLoaded', () => {
    // 初始化页面数据
    initializeData();
    
    // 添加事件监听
    addEventListeners();
});

// 初始化页面数据
function initializeData() {
    // 设置当前余额
    document.getElementById('currentBalance').textContent = '￥1,000.00';
    
    // 默认选中第一个充值金额
    document.getElementById('amount100').checked = true;
}

// 添加事件监听
function addEventListeners() {
    // 自定义金额输入框显示/隐藏
    const amountCustom = document.getElementById('amountCustom');
    const customAmountInput = document.getElementById('customAmountInput');
    
    amountCustom.addEventListener('change', function() {
        if (this.checked) {
            customAmountInput.style.display = 'block';
            customAmountInput.querySelector('input').focus();
        } else {
            customAmountInput.style.display = 'none';
        }
    });

    // 确认充值按钮点击事件
    document.getElementById('confirmRecharge').addEventListener('click', handleRecharge);

    // 退出登录按钮事件
    document.getElementById('logoutBtn').addEventListener('click', handleLogout);
}

// 处理充值
function handleRecharge() {
    // 获取选中的充值金额
    let amount = 0;
    const selectedAmount = document.querySelector('input[name="amount"]:checked');
    
    if (selectedAmount.value === 'custom') {
        amount = document.querySelector('#customAmountInput input').value;
    } else {
        amount = selectedAmount.value;
    }

    // 获取选中的支付方式
    const paymentMethod = document.querySelector('input[name="payment"]:checked').value;
    
    // 验证金额
    if (!amount || amount <= 0) {
        alert('请输入有效的充值金额');
        return;
    }

    // 显示确认弹窗
    showConfirmModal(amount, paymentMethod);
}

// 显示确认弹窗
function showConfirmModal(amount, paymentMethod) {
    const modal = document.getElementById('confirmModal');
    const confirmAmount = document.getElementById('confirmAmount');
    const confirmPayment = document.getElementById('confirmPayment');
    
    // 设置弹窗内容
    confirmAmount.textContent = `￥${parseFloat(amount).toLocaleString('zh-CN', {minimumFractionDigits: 2})}`;
    confirmPayment.textContent = getPaymentMethodName(paymentMethod);
    
    // 显示弹窗
    modal.style.display = 'block';
}

// 关闭弹窗
function closeModal() {
    document.getElementById('confirmModal').style.display = 'none';
}

// 处理支付
function processPayment() {
    // 这里可以添加实际的支付处理逻辑
    alert('支付处理中...');
    closeModal();
}

// 获取支付方式名称
function getPaymentMethodName(method) {
    const methods = {
        'wechat': '微信支付',
        'alipay': '支付宝',
        'unionpay': '银联支付'
    };
    return methods[method] || method;
}

// 处理退出登录
function handleLogout(e) {
    e.preventDefault();
    if (confirm('确定要退出登录吗？')) {
        // 这里可以添加退出登录的逻辑
        window.location.href = 'login.html';
    }
}

// 点击弹窗外部关闭弹窗
window.addEventListener('click', function(event) {
    const modal = document.getElementById('confirmModal');
    if (event.target === modal) {
        closeModal();
    }
}); 