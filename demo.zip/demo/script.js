// 模拟会员数据
const memberData = {
    name: '张三',
    level: '黄金会员',
    balance: 1000.00,
    points: 2500
};

// 页面加载完成后执行
document.addEventListener('DOMContentLoaded', () => {
    // 更新会员信息
    updateMemberInfo();

    // 退出登录按钮事件
    document.getElementById('logoutBtn').addEventListener('click', handleLogout);
});

// 更新会员信息
function updateMemberInfo() {
    document.getElementById('memberName').textContent = memberData.name;
    document.getElementById('memberLevel').textContent = memberData.level;
    document.getElementById('accountBalance').textContent = `￥${memberData.balance.toLocaleString('zh-CN', {minimumFractionDigits: 2})}`;
    document.getElementById('points').textContent = memberData.points.toLocaleString('zh-CN');
}

// 处理退出登录
function handleLogout(e) {
    e.preventDefault();
    if (confirm('确定要退出登录吗？')) {
        // 这里可以添加退出登录的逻辑
        window.location.href = 'login.html';
    }
} 