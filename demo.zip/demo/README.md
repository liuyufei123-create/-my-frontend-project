# 会员信息管理系统

这是一个简单的会员信息管理系统的前端界面，使用纯HTML、CSS和JavaScript开发。

## 功能特点

- 会员信息展示
- 账户余额管理
- 充值功能
- 交易记录查询
- 个人信息编辑
- 响应式设计，支持移动端

## 如何使用

1. 下载所有文件并保存在同一个文件夹中
2. 使用现代浏览器（如Chrome、Firefox、Edge等）直接打开 `index.html` 文件
3. 即可浏览和使用所有功能

## 文件说明

- `index.html` - 首页
- `member.html` - 会员中心页面
- `recharge.html` - 充值页面
- `styles.css` - 公共样式文件
- `member.css` - 会员中心样式
- `recharge.css` - 充值页面样式
- `script.js` - 首页脚本
- `member.js` - 会员中心脚本
- `recharge.js` - 充值页面脚本

## 注意事项

- 这是一个纯前端演示项目，暂无后端功能
- 所有数据都是模拟数据
- 支付功能仅作展示用途 